Copyright (C) 2011 Hamid Rostami

Changed by: Behnam Zakizadeh (C) 2011 AVR64.com 

GPLv3