#!/usr/bin/env python

#
#  pcb2paf.py
#
#  Copyright (C) 2011 Hamid Rostami
#
# This program is free software; you can redistribute it and/or modify
# it under the terms of the GNU General Public License version 3 as
# published by the Free Software Foundation.
#



# Revision History by Behnam Zakizadeh  (C) 2011 AVR64.com
#
# edit (a+w) to (a) in append write Mode
# add top silk layer
# add Hole Size
# add pad shape (square; RECTANGLE)
# add Via
# add Text
# add Arc and Circle
# add KeepOut layer


import os
import sys
import shutil

# ---------------- Getting information
try:
	in_filename = sys.argv[1]
	out_filename = sys.argv[2]
except:
	print "Useage: pcb2paf input_file output_file"
	exit(1)

if os.path.exists(in_filename) is not True:
	print "Give me a existing file!"
	exit(2)

# ---------------- Open files
in_file = open(in_filename, "r")

shutil.copy('P-Empty.dll', out_filename)
out_file = open(out_filename, "a")


# ---------------- Read data structures
elements = {}
layers = {}
vias = {}
temp = []

for line in in_file:
  if line.find("Element") is not -1:
    element_header = line
    temp_data = []
    for element_line in in_file:
      if element_line.find("(") is not -1:
        continue

      if element_line.find(")") is not -1:
        break;
      
      temp_data.append(element_line)
    
    elements.update( {element_header:temp_data} )
  
  if line.find("Layer") is not -1:
    layer_header = line
    temp_data = []
    for layer_line in in_file:
      if layer_line.find("(") is not -1:
        continue

      if layer_line.find(")") is not -1:
        break
      
      temp_data.append(layer_line)
    
    layers.update( {layer_header:temp_data} )

  if line.find("Via") is not -1:
    temp.append(line)

  vias.update( {'data':temp} ) 

print #empty line in prompt
print "Please wait..."
# ---------------- Draw Elemetns
for el in elements:
  info = el[ el.find('[')+1 : el.find(']') ]
  info = info.split(' ')
  mx = int(info[-7]) #  (-7) because detected from end  (why? because there are Space in file name of elemnts and it is 2nd value in element header)
  my = int(info[-6]) #  (-6) because detected from end //
  deg = int(info[-3])
  
  for line in elements[el]:
    if line.find('Pin') is not -1:
      line = line[ line.find('[')+1 : line.find(']') ]
      info = line.split(' ')
      rx = int(info[0])
      ry = int(info[1])
      thickness = int(info[2]) / 100
      drill = int(info[5]) / 100
      shape = info[8]
      x_coordinate = (mx + rx) / 100
      y_coordinate = 40000 - ((my + ry) / 100)
          
      if shape == '"square"' or shape == '"square,edge2"':
        sh = 'RECTANGLE'
      else:
        sh = 'ROUND'
          
      paf_line = '|RECORD=Pad|SELECTION=FALSE|LAYER=MULTILAYER|LOCKED=FALSE|POLYGONOUTLINE=FALSE|USERROUTED=TRUE|NAME=1|X=' + str(x_coordinate) + 'mil|Y=' + str(y_coordinate) + 'mil|XSIZE=' + str(thickness) + 'mil|YSIZE=' + str(thickness) + 'mil|SHAPE=' + sh + '|HOLESIZE=' + str(drill) + 'mil|ROTATION=0.000|PLATED=TRUE|DAISYCHAIN=Load|CCSV=0|CPLV=0|CCWV=1|CENV=1|CAGV=1|CPEV=1|CSEV=1|CPCV=1|CPRV=1|CCW=10mil|CEN=4|CAG=10mil|CPE=0mil|CSE=4mil|CPC=20mil|CPR=20mil\n'
      
      out_file.write(paf_line)
      #print "Wrote " + sh + " PAD"

    elif line.find('ElementLine') is not -1:
      line = line[ line.find('[')+1 : line.find(']') ]
      info = line.split(' ')
      rx1 = int(info[0])
      ry1 = int(info[1])
      rx2 = int(info[2])
      ry2 = int(info[3])
      thickness = int(info[4]) / 100
      
      rx1_coordinate = (mx + rx1) / 100
      ry1_coordinate = 40000 - ((my + ry1) / 100)
      rx2_coordinate = (mx + rx2) / 100
      ry2_coordinate = 40000 - ((my + ry2) / 100)
          
      
      paf_line = '|RECORD=Track|SELECTION=FALSE|LAYER=TOPOVERLAY|LOCKED=FALSE|POLYGONOUTLINE=FALSE|USERROUTED=TRUE|X1=' + str(rx1_coordinate) + 'mil|Y1=' + str(ry1_coordinate) + 'mil|X2=' + str(rx2_coordinate) + 'mil|Y2=' + str(ry2_coordinate) + 'mil|WIDTH=' + str(thickness) + 'mil|SUBPOLYINDEX=0\n'
      
      
      out_file.write(paf_line)
      #print "Wrote ElementLine"

    elif line.find('ElementArc') is not -1:
      line = line[ line.find('[')+1 : line.find(']') ]
      info = line.split(' ')
      rx1 = int(info[0])
      ry1 = int(info[1])
      radius = int(info[2]) / 100
      start = int(info[4])
      delta = int(info[5])
      thickness = int(info[6]) / 100
      
      rx1_coordinate = (mx + rx1) / 100
      ry1_coordinate = 40000 - ((my + ry1) / 100)
      
      #calculate Start and End (because we have Start and Delta)
      
      
      # reserved for next revision
      if deg == 0:
        d = 0
      elif deg == 1:
        d = 90
      elif deg == 2:
        d = 180
      elif deg == 3:
        d = 270
      
      A = start + 180
      if A > 360:
        A = A - 360
      
      B = A + delta 
      if B > 360:
        B = B - 360
      
      startArc = A
      endArc = B
      
      if startArc > 360:
        startArc = startArc - 360
        
      if endArc > 360:
        endArc = endArc - 360
      
      
      
      paf_line = '|RECORD=Arc|SELECTION=FALSE|LAYER=TOPOVERLAY|LOCKED=FALSE|POLYGONOUTLINE=FALSE|USERROUTED=TRUE|LOCATION.X=' + str(rx1_coordinate) + 'mil|LOCATION.Y=' + str(ry1_coordinate) + 'mil|RADIUS=' + str(radius) + 'mil|STARTANGLE=' + str(startArc) + '|ENDANGLE=' + str(endArc) + '|WIDTH=' + str(thickness) + 'mil|SUBPOLYINDEX=0\n'
      out_file.write(paf_line)
      #print "Wrote ARC"

# ---------------- Draw Vias
for el in vias:
  data = 'skip a line ;) '
for via in vias[el]:
 if via.find('Via') is not -1:
  info = via[ via.find('[')+1 : via.find(']') ]
  info = info.split(' ')
  vx = int(info[0]) / 100
  vy = 40000 - (int(info[1]) / 100)
  diameter = int(info[2]) / 100
  drill = int(info[5]) / 100
  
  paf_line = '|RECORD=Via|SELECTION=FALSE|LAYER=MULTILAYER|LOCKED=FALSE|POLYGONOUTLINE=FALSE|USERROUTED=TRUE|X=' + str(vx) + 'mil|Y=' + str(vy) + 'mil|DIAMETER=' + str(diameter) + 'mil|HOLESIZE=' + str(drill) + 'mil|STARTLAYER=TOP|ENDLAYER=BOTTOM|CCSV=0|CPLV=0|CCWV=1|CENV=1|CAGV=1|CPEV=0|CSEV=1|CPCV=1|CPRV=1|CCW=10mil|CEN=4|CAG=10mil|CSE=4mil|CPC=20mil|CPR=20mil\n'
  out_file.write(paf_line)
  #print "Wrote Via"

# ---------------- Test area
for l in layers:
  if l.find('solder') is not -1:
    layer = 'BOTTOM'
  elif l.find('component') is not -1:
    layer = 'TOP'
  elif l.find('silk') is not -1:
    layer = 'TOPOVERLAY'
  elif l.find('keepOut') is not -1:
    layer = 'KEEPOUT'  
    
    
  else:
    layer = None
  
  if layer is not None:
    for line in layers[l]:
      if line.find('Line') is not -1:
        line = line[ line.find('[')+1 : line.find(']') ]
        info = line.split(' ')
        x1 = int(info[0]) / 100
        y1 = 40000 - (int(info[1]) / 100)
        x2 = int(info[2]) / 100
        y2 = 40000 - (int(info[3]) / 100)
        thickness = int(info[4]) / 100
        
        paf_line = '|RECORD=Track|SELECTION=FALSE|LAYER=' + layer + '|LOCKED=FALSE|POLYGONOUTLINE=FALSE|USERROUTED=TRUE|X1=' + str(x1) + 'mil|Y1=' + str(y1) + 'mil|X2=' + str(x2) + 'mil|Y2=' + str(y2) + 'mil|WIDTH=' + str(thickness) + 'mil|SUBPOLYINDEX=0\n'
        out_file.write(paf_line)
        #print "Wrote " + layer + " Line"
        

    for line in layers[l]:
      if line.find('Text') is not -1:
        line = line[ line.find('[')+1 : line.find(']') ]
        info = line.split(' ')
        x = int(info[0]) / 100
        y = 40000 - (int(info[1]) / 100)
        deg = int(info[2])
        scale = int(info[3])
        text = info[4]
        mirror = info[5]
        
        # because there is a bug in PCB for bottom text ! 
        if layer == 'BOTTOM':
          if deg == 2:
             deg = 0
          elif deg == 1:
             deg = 1
          elif deg == 0:
             deg = 2
          elif deg == 3:
             deg = 3
        
        if deg == 0:
          d = '0.000'
        elif deg == 1:
          d = '90.000'
        elif deg == 2:
          d = '180.000'
        elif deg == 3:
          d = '270.000'


        if mirror == '"auto"':
          mir = 'TRUE'
        else:
          mir = 'FALSE'

        paf_line = '|RECORD=Text|SELECTION=FALSE|LAYER=' + layer + '|LOCKED=FALSE|POLYGONOUTLINE=FALSE|USERROUTED=TRUE|X=' + str(x-40) + 'mil|Y=' + str(y-50) + 'mil|HEIGHT=' + str(scale*.4) + 'mil|FONT=DEFAULT|ROTATION=' + d + '|MIRROR=' + mir + '|TEXT=' + text + '|WIDTH=' + str(scale / 12) + 'mil\n'
        out_file.write(paf_line)
        #print "Wrote Text on " + layer + " layer"

  
out_file.close()  
print "END"
