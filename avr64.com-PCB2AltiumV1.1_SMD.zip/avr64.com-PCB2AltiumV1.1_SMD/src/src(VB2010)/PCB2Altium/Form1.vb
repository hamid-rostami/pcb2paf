﻿' PCB2Altium Converted to VB from python By Behnam Zakizadeh @ 05.02.1392 [2013] www.avr64.com
' Originaly by Hamid Rostami 2011 with python:
' pcb2paf.py
' Copyright (C) 2011 Hamid Rostami
' This program is free software; you can redistribute it and/or modify
' it under the terms of the GNU General Public License version 3 as
' published by the Free Software Foundation.
'
' Revision History by Behnam Zakizadeh  (C) 2011 AVR64.com (in python version)
'
' edit (a+w) to (a) in append write Mode
' add top silk layer
' add Hole Size
' add pad shape (square; RECTANGLE)
' add Via
' add Text
' add Arc and Circle
' add KeepOut layer

' Ver 1.1
' Edited @ 18.04.1394
' Support SMD components


Imports System.IO
Public Class Form1
    'Global Vars
    Private input As FileStream
    Private fileReader As StreamReader
    Public fileName As String
    Private input2 As FileStream
    Private fileReader2 As StreamReader
    Dim fil As Byte


    Private Sub Form1_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load

    End Sub

    Private Sub AboutToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles AboutToolStripMenuItem.Click
        AboutBox1.Show()
    End Sub

    Private Sub ExitToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ExitToolStripMenuItem.Click
        Application.Exit()
    End Sub

    Private Sub Button1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button1.Click
        openf()
    End Sub

    Private Sub Button2_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button2.Click
        convert()
    End Sub

    Sub convert()
        If fil = 1 Then
            'Dim exePath As String = Application.ExecutablePath()
            Dim strPath As String = Application.StartupPath()

            input2 = New FileStream(strPath & "\template.dll", FileMode.Open, FileAccess.Read)
            fileReader2 = New StreamReader(input2)

            Dim fileLoc As String = strPath & "\Output_Altium.pcbdoc"
            Dim fs As FileStream = Nothing
            If (Not File.Exists(fileLoc)) Then
                fs = File.Create(fileLoc)
                Using fs

                End Using
            End If
            If File.Exists(fileLoc) Then
                Using sw As StreamWriter = New StreamWriter(fileLoc)
                    'If you set the second parameter to True in the System.IO.StreamWriter's constructor it will append to a file if it already exists, or create a new one if it doesn't.

                    'copy template to save.txt
                    Dim line2 As String
                    Do While fileReader2.Peek() >= 0
                        line2 = fileReader2.ReadLine()
                        sw.WriteLine(line2)
                    Loop

                    'convert
                    Dim buf(100000) As String
                    Dim i As Integer
                    i = 0
                    Dim line As String
                    Do While fileReader.Peek() >= 0
                        line = fileReader.ReadLine()
                        buf(i) = line
                        i += 1
                    Loop

                    Dim j As Integer
                    Dim l As String, lin As String
                    Dim k As Integer
                    Dim mx1 As Integer, my1 As Integer, deg As Integer
                    Dim rx As Integer, ry As Integer, thickness As Integer, rx_2 As Integer, ry_2 As Integer

                    Dim drill As Integer, shape As String, x_coordinate As Integer
                    Dim y_coordinate As Integer, sh As String, paf_line As String

                    Dim rx1 As String, rx2 As String, ry1 As String, ry2 As String
                    Dim rx1_coordinate As String, rx2_coordinate As String
                    Dim ry1_coordinate As String, ry2_coordinate As String

                    Dim radius As Integer, start As Integer, delta As Integer
                    Dim a As Integer, b As Integer
                    Dim startArc As Integer, endarc As Integer

                    Dim vx As Integer, vy As Integer, diameter As Integer

                    Dim x1 As Integer, y1 As Integer, x2 As Integer, y2 As Integer
                    Dim layer As String

                    Dim x As Integer, y As Integer, scale As Integer, text As String, mirror As String
                    Dim d As String, mir As String

                    Dim definedlayer As Byte
                    definedlayer = 0

                    For j = 0 To i - 1
                        lin = buf(j)

                        If lin.StartsWith("Element") Then
                            Dim tmp() As String = Split(lin)
                            mx1 = tmp(tmp.Length - 7)
                            my1 = tmp(tmp.Length - 6)
                            deg = tmp(tmp.Length - 3)

                            'MessageBox.Show("tmp.Length: " & tmp.Length)
                            'MessageBox.Show("tmp.Length - 7: " & mx1)

                            For k = j To i - 1
                                l = buf(k)
                                If l.Contains("(") Then
                                    Continue For
                                End If
                                If l.Contains(")") Then
                                    Exit For
                                End If

                                If l.Contains("Pin") Then

                                    l = l.Replace("[", " ")
                                    l = l.Replace("]", " ")

                                    Dim tmp1() As String = Split(l)
                                    rx = tmp1(1)
                                    ry = tmp1(2)
                                    thickness = tmp1(3) / 100
                                    drill = tmp1(6) / 100
                                    shape = tmp1(9)
                                    x_coordinate = (mx1 + rx) / 100
                                    y_coordinate = 40000 - ((my1 + ry) / 100)

                                    If shape.Contains("square") Then
                                        sh = "RECTANGLE"
                                    Else
                                        sh = "ROUND"
                                    End If

                                    paf_line = "|RECORD=Pad|INDEXFORSAVE=0|SELECTION=FALSE|LAYER=MULTILAYER|LOCKED=FALSE|POLYGONOUTLINE=FALSE|USERROUTED=TRUE|UNIONINDEX=0|NAME=2|X=" & x_coordinate & "mil|Y=" & y_coordinate & "mil|XSIZE=" & thickness & "mil|YSIZE=" & thickness & "mil|SHAPE=" & sh & "|HOLESIZE=" & drill & "mil|ROTATION= 0.00000000000000E+0000|PLATED=TRUE|DAISYCHAIN=Load|CCSV=0|CPLV=0|CCWV=1|CENV=1|CAGV=1|CPEV=1|CSEV=1|CPCV=1|CPRV=1|CCW=10mil|CEN=4|CAG=10mil|CPE=0mil|CSE=4mil|CPC=20mil|CPR=20mil|PADMODE=0|SWAPID_PAD=|SWAPID_GATE=|&|0|SWAPPEDPADNAME=|GATEID=0|OVERRIDEWITHV6_6SHAPES=FALSE|DRILLTYPE=0|HOLETYPE=0|HOLEWIDTH=33.4646mil|HOLEROTATION= 0.00000000000000E+0000|PADXOFFSET0=0mil|PADYOFFSET0=0mil|PADXOFFSET1=0mil|PADYOFFSET1=0mil|PADXOFFSET2=0mil|PADYOFFSET2=0mil|PADXOFFSET3=0mil|PADYOFFSET3=0mil|PADXOFFSET4=0mil|PADYOFFSET4=0mil|PADXOFFSET5=0mil|PADYOFFSET5=0mil|PADXOFFSET6=0mil|PADYOFFSET6=0mil|PADXOFFSET7=0mil|PADYOFFSET7=0mil|PADXOFFSET8=0mil|PADYOFFSET8=0mil|PADXOFFSET9=0mil|PADYOFFSET9=0mil|PADXOFFSET10=0mil|PADYOFFSET10=0mil|PADXOFFSET11=0mil|PADYOFFSET11=0mil|PADXOFFSET12=0mil|PADYOFFSET12=0mil|PADXOFFSET13=0mil|PADYOFFSET13=0mil|PADXOFFSET14=0mil|PADYOFFSET14=0mil|PADXOFFSET15=0mil|PADYOFFSET15=0mil|PADXOFFSET16=0mil|PADYOFFSET16=0mil|PADXOFFSET17=0mil|PADYOFFSET17=0mil|PADXOFFSET18=0mil|PADYOFFSET18=0mil|PADXOFFSET19=0mil|PADYOFFSET19=0mil|PADXOFFSET20=0mil|PADYOFFSET20=0mil|PADXOFFSET21=0mil|PADYOFFSET21=0mil|PADXOFFSET22=0mil|PADYOFFSET22=0mil|PADXOFFSET23=0mil|PADYOFFSET23=0mil|PADXOFFSET24=0mil|PADYOFFSET24=0mil|PADXOFFSET25=0mil|PADYOFFSET25=0mil|PADXOFFSET26=0mil|PADYOFFSET26=0mil|PADXOFFSET27=0mil|PADYOFFSET27=0mil|PADXOFFSET28=0mil|PADYOFFSET28=0mil|PADXOFFSET29=0mil|PADYOFFSET29=0mil|PADXOFFSET30=0mil|PADYOFFSET30=0mil|PADXOFFSET31=0mil|PADYOFFSET31=0mil|PADJUMPERID=0"

                                    sw.WriteLine(paf_line)

                                End If 'pins

                                '===== pad (ver 1.1)
                                If l.Contains("Pad") Then

                                    l = l.Replace("[", " ")
                                    l = l.Replace("]", " ")

                                    Dim tmp1() As String = Split(l)
                                    rx = tmp1(1)
                                    ry = tmp1(2)
                                    rx_2 = tmp1(3)
                                    ry_2 = tmp1(4)
                                    thickness = tmp1(5) / 100
                                    x_coordinate = (mx1 + rx) / 100
                                    y_coordinate = 40000 - ((my1 + ry) / 100)


                                    Dim tool As Integer, x_size As Integer, y_size As Integer
                                    If ry = ry_2 Then
                                        ' ofoghi ==
                                        tool = Math.Abs(rx - rx_2)
                                        tool = tool / 100
                                        x_size = tool + thickness
                                        y_size = thickness
                                        x_coordinate = x_coordinate + (tool / 2)
                                    End If
                                    If rx = rx_2 Then
                                        ' amoodi   |
                                        tool = Math.Abs(ry - ry_2)
                                        tool = tool / 100
                                        y_size = tool + thickness
                                        x_size = thickness
                                        y_coordinate = y_coordinate - (tool / 2)
                                    End If







                                    'drill = tmp1(6) / 100
                                    shape = tmp1(10)
                                    

                                    If shape.Contains("square") Then
                                        sh = "RECTANGLE"
                                    Else
                                        sh = "ROUND"
                                    End If



                                    'paf_line = "|RECORD=Pad|INDEXFORSAVE=0|SELECTION=FALSE|LAYER=MULTILAYER|LOCKED=FALSE|POLYGONOUTLINE=FALSE|USERROUTED=TRUE|UNIONINDEX=0|NAME=2|X=" & x_coordinate & "mil|Y=" & y_coordinate & "mil|XSIZE=" & thickness & "mil|YSIZE=" & thickness & "mil|SHAPE=" & sh & "|HOLESIZE=" & drill & "mil|ROTATION= 0.00000000000000E+0000|PLATED=TRUE|DAISYCHAIN=Load|CCSV=0|CPLV=0|CCWV=1|CENV=1|CAGV=1|CPEV=1|CSEV=1|CPCV=1|CPRV=1|CCW=10mil|CEN=4|CAG=10mil|CPE=0mil|CSE=4mil|CPC=20mil|CPR=20mil|PADMODE=0|SWAPID_PAD=|SWAPID_GATE=|&|0|SWAPPEDPADNAME=|GATEID=0|OVERRIDEWITHV6_6SHAPES=FALSE|DRILLTYPE=0|HOLETYPE=0|HOLEWIDTH=33.4646mil|HOLEROTATION= 0.00000000000000E+0000|PADXOFFSET0=0mil|PADYOFFSET0=0mil|PADXOFFSET1=0mil|PADYOFFSET1=0mil|PADXOFFSET2=0mil|PADYOFFSET2=0mil|PADXOFFSET3=0mil|PADYOFFSET3=0mil|PADXOFFSET4=0mil|PADYOFFSET4=0mil|PADXOFFSET5=0mil|PADYOFFSET5=0mil|PADXOFFSET6=0mil|PADYOFFSET6=0mil|PADXOFFSET7=0mil|PADYOFFSET7=0mil|PADXOFFSET8=0mil|PADYOFFSET8=0mil|PADXOFFSET9=0mil|PADYOFFSET9=0mil|PADXOFFSET10=0mil|PADYOFFSET10=0mil|PADXOFFSET11=0mil|PADYOFFSET11=0mil|PADXOFFSET12=0mil|PADYOFFSET12=0mil|PADXOFFSET13=0mil|PADYOFFSET13=0mil|PADXOFFSET14=0mil|PADYOFFSET14=0mil|PADXOFFSET15=0mil|PADYOFFSET15=0mil|PADXOFFSET16=0mil|PADYOFFSET16=0mil|PADXOFFSET17=0mil|PADYOFFSET17=0mil|PADXOFFSET18=0mil|PADYOFFSET18=0mil|PADXOFFSET19=0mil|PADYOFFSET19=0mil|PADXOFFSET20=0mil|PADYOFFSET20=0mil|PADXOFFSET21=0mil|PADYOFFSET21=0mil|PADXOFFSET22=0mil|PADYOFFSET22=0mil|PADXOFFSET23=0mil|PADYOFFSET23=0mil|PADXOFFSET24=0mil|PADYOFFSET24=0mil|PADXOFFSET25=0mil|PADYOFFSET25=0mil|PADXOFFSET26=0mil|PADYOFFSET26=0mil|PADXOFFSET27=0mil|PADYOFFSET27=0mil|PADXOFFSET28=0mil|PADYOFFSET28=0mil|PADXOFFSET29=0mil|PADYOFFSET29=0mil|PADXOFFSET30=0mil|PADYOFFSET30=0mil|PADXOFFSET31=0mil|PADYOFFSET31=0mil|PADJUMPERID=0"

                                    'new
                                    paf_line = "|RECORD=Pad|COMPONENT=0|SELECTION=FALSE|LAYER=MULTILAYER|LOCKED=FALSE|POLYGONOUTLINE=FALSE|USERROUTED=TRUE|NAME=2|X=" & x_coordinate & "mil|Y=" & y_coordinate & "mil|XSIZE=" & x_size & "|YSIZE=" & y_size & "|SHAPE=" & sh & "|HOLESIZE=0mil|ROTATION=0.000|PLATED=TRUE|DAISYCHAIN=Load|CCSV=0|CPLV=0|CCWV=1|CENV=1|CAGV=1|CPEV=1|CSEV=1|CPCV=1|CPRV=1|CCW=10mil|CEN=4|CAG=10mil|CPE=0mil|CSE=4mil|CPC=20mil|CPR=20mil"

                                    sw.WriteLine(paf_line)

                                End If 'pad


                                If l.Contains("ElementLine") Then

                                    l = l.Replace("[", " ")
                                    l = l.Replace("]", " ")

                                    Dim tmp2() As String = Split(l)

                                    rx1 = tmp2(2)
                                    ry1 = tmp2(3)
                                    rx2 = tmp2(4)
                                    ry2 = tmp2(5)
                                    thickness = tmp2(6) / 100

                                    rx1_coordinate = (mx1 + rx1) / 100
                                    ry1_coordinate = 40000 - ((my1 + ry1) / 100)
                                    rx2_coordinate = (mx1 + rx2) / 100
                                    ry2_coordinate = 40000 - ((my1 + ry2) / 100)

                                    paf_line = "|RECORD=Track|INDEXFORSAVE=2|SELECTION=FALSE|LAYER=TOPOVERLAY|LOCKED=FALSE|POLYGONOUTLINE=FALSE|USERROUTED=TRUE|UNIONINDEX=0|X1=" & rx1_coordinate & "mil|Y1=" & ry1_coordinate & "mil|X2=" & rx2_coordinate & "mil|Y2=" & ry2_coordinate & "mil|WIDTH=" & thickness & "mil|SUBPOLYINDEX=0"

                                    sw.WriteLine(paf_line)

                                End If 'ElementLine

                                If l.Contains("ElementArc") Then

                                    l = l.Replace("[", " ")
                                    l = l.Replace("]", " ")

                                    Dim tmp2() As String = Split(l)

                                    rx1 = tmp2(2)
                                    ry1 = tmp2(3)
                                    radius = tmp2(4) / 100
                                    start = tmp2(6)
                                    delta = tmp2(7)
                                    thickness = tmp2(8) / 100

                                    rx1_coordinate = (mx1 + rx1) / 100
                                    ry1_coordinate = 40000 - ((my1 + ry1) / 100)

                                    a = start + 180
                                    If a > 360 Then a = a - 360

                                    b = a + delta
                                    If b > 360 Then b = b - 360

                                    startArc = a
                                    endarc = b

                                    If startArc > 360 Then startArc = startArc - 360

                                    If endarc > 360 Then endarc = endarc - 360

                                    paf_line = "|RECORD=Arc|SELECTION=FALSE|LAYER=TOPOVERLAY|LOCKED=FALSE|POLYGONOUTLINE=FALSE|USERROUTED=TRUE|LOCATION.X=" & rx1_coordinate & "mil|LOCATION.Y=" & ry1_coordinate & "mil|RADIUS=" & radius & "mil|STARTANGLE=" & startArc & "|ENDANGLE=" & endarc & "|WIDTH=" & thickness & "mil|SUBPOLYINDEX=0"
                                    sw.WriteLine(paf_line)
                                End If 'ElementArc
                            Next
                        End If 'Element

                        If lin.StartsWith("Via") Then

                            l = lin.Replace("[", " ")
                            l = l.Replace("]", " ")

                            Dim tmp2() As String = Split(l)

                            vx = tmp2(1) / 100
                            vy = 40000 - (tmp2(2) / 100)
                            diameter = tmp2(3) / 100
                            drill = tmp2(6) / 100

                            paf_line = "|RECORD=Via|SELECTION=FALSE|LAYER=MULTILAYER|LOCKED=FALSE|POLYGONOUTLINE=FALSE|USERROUTED=TRUE|X=" & vx & "mil|Y=" & vy & "mil|DIAMETER=" & diameter & "mil|HOLESIZE=" & drill & "mil|STARTLAYER=TOP|ENDLAYER=BOTTOM|CCSV=0|CPLV=0|CCWV=1|CENV=1|CAGV=1|CPEV=0|CSEV=1|CPCV=1|CPRV=1|CCW=10mil|CEN=4|CAG=10mil|CSE=4mil|CPC=20mil|CPR=20mil"
                            sw.WriteLine(paf_line)
                        End If 'via
                        layer = ""
                        definedlayer = 0
                        If lin.StartsWith("Layer") Then
                            If lin.Contains("component") Then
                                layer = "TOP"
                                definedlayer = 1
                            End If
                            If lin.Contains("solder") Then
                                layer = "BOTTOM"
                                definedlayer = 1
                            End If
                            If lin.Contains("silk") Then
                                layer = "TOPOVERLAY"
                                definedlayer = 1
                            End If
                            If lin.Contains("keepOut") Then
                                layer = "KEEPOUT"
                                definedlayer = 1
                            End If

                            If definedlayer = 1 Then


                                For k = j To i - 1
                                    l = buf(k)
                                    If l.Contains("(") Then
                                        Continue For
                                    End If
                                    If l.Contains(")") Then
                                        Exit For
                                    End If

                                    If l.Contains("Line") Then

                                        l = l.Replace("[", " ")
                                        l = l.Replace("]", " ")

                                        Dim tmp1() As String = Split(l)

                                        x1 = tmp1(1) / 100
                                        y1 = 40000 - (tmp1(2) / 100)
                                        x2 = tmp1(3) / 100
                                        y2 = 40000 - (tmp1(4) / 100)
                                        thickness = tmp1(5) / 100
                                        paf_line = "|RECORD=Track|INDEXFORSAVE=2|SELECTION=FALSE|LAYER=" & layer & "|LOCKED=FALSE|POLYGONOUTLINE=FALSE|USERROUTED=TRUE|UNIONINDEX=0|X1=" & x1 & "mil|Y1=" & y1 & "mil|X2=" & x2 & "mil|Y2=" & y2 & "mil|WIDTH=" & thickness & "mil|SUBPOLYINDEX=0"
                                        sw.WriteLine(paf_line)
                                    End If

                                    'have bug:
                                    'If l.Contains("Arc") Then

                                    'l = l.Replace("[", " ")
                                    'l = l.Replace("]", " ")

                                    'Dim tmp1() As String = Split(l)

                                    'rx1_coordinate = tmp1(1) / 100
                                    'ry1_coordinate = 40000 - (tmp1(2) / 100)

                                    'radius = tmp1(3) / 100
                                    'start = tmp1(5)
                                    'delta = tmp1(6)
                                    'thickness = tmp1(7) / 100

                                    'a = start + 180
                                    'If a > 360 Then a = a - 360
                                    'b = a + delta
                                    'If b > 360 Then b = b - 360
                                    'startArc = a
                                    'endarc = b
                                    'If startArc > 360 Then startArc = startArc - 360
                                    'If endarc > 360 Then endarc = endarc - 360

                                    'paf_line = "|RECORD=Arc|SELECTION=FALSE|LAYER=" & layer & "|LOCKED=FALSE|POLYGONOUTLINE=FALSE|USERROUTED=TRUE|LOCATION.X=" & rx1_coordinate & "mil|LOCATION.Y=" & ry1_coordinate & "mil|RADIUS=" & radius & "mil|STARTANGLE=" & startArc & "|ENDANGLE=" & endarc & "|WIDTH=" & thickness & "mil|SUBPOLYINDEX=0"
                                    'sw.WriteLine(paf_line)

                                    ' End If
                                    If l.Contains("Text") Then
                                        l = l.Replace("[", " ")
                                        l = l.Replace("]", " ")
                                        Dim tmp1() As String = Split(l)
                                        x = tmp1(1) / 100
                                        y = 40000 - (tmp1(2) / 100)
                                        deg = tmp1(3)
                                        scale = tmp1(4)
                                        text = tmp1(5)
                                        mirror = tmp1(6)
                                        If layer = "BOTTOM" Then
                                            If deg = 2 Then
                                                deg = 0
                                            ElseIf deg = 1 Then
                                                deg = 1
                                            ElseIf deg = 0 Then
                                                deg = 2
                                            ElseIf deg = 3 Then
                                                deg = 3
                                            End If
                                        End If
                                        d = ""
                                        If deg = 0 Then
                                            d = "0.000"
                                        ElseIf deg = 1 Then
                                            d = "90.000"
                                        ElseIf deg = 2 Then
                                            d = "180.000"
                                        ElseIf deg = 3 Then
                                            d = "270.000"
                                        End If
                                        If mirror.Contains("auto") Then
                                            mir = "TRUE"
                                        Else
                                            mir = "FALSE"
                                        End If
                                        paf_line = "|RECORD=Text|SELECTION=FALSE|LAYER=" & layer & "|LOCKED=FALSE|POLYGONOUTLINE=FALSE|USERROUTED=TRUE|X=" & (x - 40) & "mil|Y=" & (y - 50) & "mil|HEIGHT=" & (scale * 0.4) & "mil|FONT=DEFAULT|ROTATION=" & d & "|MIRROR=" & mir & "|TEXT=" & text & "|WIDTH=" & (scale / 12) & "mil"
                                        sw.WriteLine(paf_line)
                                    End If
                                Next
                            End If
                        End If
                    Next
                End Using
            End If
            MessageBox.Show("Converted!")
            Button2.Enabled = False
            ConvertToolStripMenuItem1.Enabled = False
            Button1.Enabled = False
            OpenToolStripMenuItem.Enabled = False
            Application.Exit()
        Else
            MessageBox.Show("No File Selected!", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error)
        End If
    End Sub

    Private Sub ConvertToolStripMenuItem1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ConvertToolStripMenuItem1.Click
        convert()
    End Sub

    Sub openf()
        Dim result As DialogResult

        Using fileChooser As New OpenFileDialog()
            result = fileChooser.ShowDialog()
            fileName = fileChooser.FileName
        End Using

        If result <> DialogResult.Cancel Then
            fil = 1
            input = New FileStream(fileName, FileMode.Open, FileAccess.Read)
            fileReader = New StreamReader(input)
            Label1.Text = Path.GetFileName(fileName)
        End If
    End Sub

    Private Sub OpenToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles OpenToolStripMenuItem.Click
        openf()
    End Sub
End Class
