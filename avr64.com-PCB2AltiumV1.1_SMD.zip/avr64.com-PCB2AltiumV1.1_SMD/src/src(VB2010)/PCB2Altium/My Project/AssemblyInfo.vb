﻿Imports System
Imports System.Reflection
Imports System.Runtime.InteropServices

' General Information about an assembly is controlled through the following 
' set of attributes. Change these attribute values to modify the information
' associated with an assembly.

' Review the values of the assembly attributes

<Assembly: AssemblyTitle("PCB2Altium")> 
<Assembly: AssemblyDescription("PCB2Altium Is a free GNU Project by Hamid Rostami. Original project was crated in python, Converted to windows by Behnam Zakizadeh, here is original copyright: pcb2paf.py Copyright (C) 2011 Hamid Rostami. This program is free software; you can redistribute it and/or modify it under the terms of the GNU General Public License version 3 as published by the Free Software Foundation.")> 
<Assembly: AssemblyCompany("AVR64.com")> 
<Assembly: AssemblyProduct("PCB2Altium")> 
<Assembly: AssemblyCopyright("Copyright © AVR64.com 2013")> 
<Assembly: AssemblyTrademark("")> 

<Assembly: ComVisible(False)>

'The following GUID is for the ID of the typelib if this project is exposed to COM
<Assembly: Guid("1b1a5cb0-d44c-408c-8bf0-3c12104eea98")> 

' Version information for an assembly consists of the following four values:
'
'      Major Version
'      Minor Version 
'      Build Number
'      Revision
'
' You can specify all the values or you can default the Build and Revision Numbers 
' by using the '*' as shown below:
' <Assembly: AssemblyVersion("1.0.*")> 

<Assembly: AssemblyVersion("1.1.0.0")> 
<Assembly: AssemblyFileVersion("1.1.0.0")> 
